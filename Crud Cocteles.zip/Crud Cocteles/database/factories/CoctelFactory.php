<?php

use Faker\Generator as Faker;

$factory->define(App\coctel::class, function (Faker $faker) {
    return [
        'title' => $faker->text(20),
        'ingredients' => $faker->text(80),
    ];
});
