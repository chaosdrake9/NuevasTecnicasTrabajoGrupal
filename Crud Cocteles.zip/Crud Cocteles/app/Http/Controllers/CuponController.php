<?php

namespace App\Http\Controllers;

use App\Cupon;
use App\Http\Resources\CuponResource;
use Illuminate\Http\Request;

class CuponController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cupones = Cupon::paginate();
        return CuponResource::collection($cupones);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $cupon = new Cupon;
        $cupon->id = $request->input('id');
        $cupon->categoria = $request->input('categoria');
        $cupon->descuento = $request->input('descuento');
        if ($cupon->save()) {
            return new CuponResource($cupon);
        }

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // $cupon = $request->isMethod('put') ? Cupon::findOrFail($request->id) : new Cupon;
        // //echo $request;
        // $cupon->id = $request->input('id');
        // $cupon->categoria = $request->input('categoria');
        // $cupon->descuento = $request->input('descuento');

        // if ($cupon->save()) {
        //     //return new CuponResource($cupon);
        // }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $cupon = Cupon::findOrFail($id);
        return new CuponResource($cupon);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $iden)
    {
        $cupon = Cupon::findOrFail($iden);
//echo $request;
        $cupon->id = $iden;
        $cupon->categoria = $request->input('categoria');
        $cupon->descuento = $request->input('descuento');

        if ($cupon->save()) {
            return new CuponResource($cupon);
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $cupon = Cupon::findOrFail($id);
        if ($cupon->delete()) {
            return new CuponResource($cupon);
        }

    }
}
