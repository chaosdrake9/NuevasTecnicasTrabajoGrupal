<?php

namespace App\Http\Controllers;

use App\coctel;
use App\Http\Resources\CoctelRes as CoctelResource;
use Illuminate\Http\Request;

// use App\Http\Requests;

class Cocteleria extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Get cocteles
        $coctels = coctel::orderBy('created_at', 'desc')->paginate(9);

        // Return collection of cocteles as a resource
        return CoctelResource::collection($coctels);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $coctel = $request->isMethod('put') ? coctel::findOrFail($request->coctel_id) : new coctel;

        $coctel->id = $request->input('coctel_id');
        $coctel->title = $request->input('title');
        $coctel->ingredients = $request->input('ingredients');

        if ($coctel->save()) {
            return new CoctelResource($coctel);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // Get coctel
        $coctel = coctel::findOrFail($id);

        // Return single coctel as a resource
        return new CoctelResource($coctel);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Get coctel
        $coctel = coctel::findOrFail($id);

        if ($coctel->delete()) {
            return new CoctelResource($coctel);
        }

    }
}
