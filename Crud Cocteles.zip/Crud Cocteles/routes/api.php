<?php
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE');
use Illuminate\Http\Request;

// header('Access-Control-Allow-Headers: Content-Type, X-Auth-Token, Origin, Authorization');
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
 */

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

// List articles
Route::get('articles', 'ArticleController@index');

// List single article
Route::get('article/{id}', 'ArticleController@show');

// Create new article
Route::post('article', 'ArticleController@store');

// Update article
Route::put('article', 'ArticleController@store');

// Delete article
Route::delete('article/{id}', 'ArticleController@destroy');

Route::get('Usuarios', 'Usuarios@index');
Route::get('Usuarios/{id}', 'Usuarios@show');
Route::post('Usuarios', 'Usuarios@store');
Route::put('Usuarios', 'Usuarios@store');
Route::delete('Usuarios/{id}', 'Usuarios@destroy');

// Route::resource('Usuario', 'Usuarios');

Route::get('Cupones', 'CuponController@index');
Route::get('Cupones/{id}', 'CuponController@show');
Route::post('Cupones', 'CuponController@create');
//por alguna razon no funciona la ruta put, no se pasan los datos del request desde postman
Route::post('Cupones/{iden}', 'CuponController@update');
Route::delete('Cupones/{id}', 'CuponController@destroy');

// Cocteles

// List coctels
Route::get('coctels', 'Cocteleria@index');

// List single coctel
Route::get('coctel/{id}', 'Cocteleria@show');

// Create new coctel
Route::post('coctel', 'Cocteleria@store');

// Update coctel
Route::put('coctel', 'Cocteleria@store');

// Delete coctel
Route::delete('coctel/{id}', 'Cocteleria@destroy');
