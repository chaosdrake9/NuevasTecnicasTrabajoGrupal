new Vue({
  el: '#app',
  data: {
    message: 'Hola Mundo-chan no tengo idea que poner en css XD'
  }
})
